package br.com.tutorial.calculadora.model;

/*Essa classe cria as doubles: "valor1", "valor2" e "resultado" e gera os getters e setters*/
public class CalculadoraModel {
    double valor1, valor2, resultado;
    
    public CalculadoraModel(){
    valor1 = 0;
    valor2 = 0;
    resultado = 0;
    }
    
    /*Esse metodo soma valor1 e valor2 e armazena em "resultado"*/
    public void somar(){
    resultado = valor1 + valor2;
    }
    
    /*Esse metodo subtrai valor1 e valor2 e armazena em "resultado"*/
    public void subtracao(){
    resultado = valor1 - valor2;
    }
    
    /*Esse metodo divide valor1 e valor2 e armazena em "resultado"*/
    public void divisao(){
    resultado = valor1 / valor2;
    }
    
    /*Esse metodo multiplicacao valor1 e valor2 e armazena em "resultado"*/
    public void multiplicacao(){
    resultado = valor1 * valor2;
    }

    public double getValor1() {
        return valor1;
    }

    public void setValor1(double valor1) {
        this.valor1 = valor1;
    }

    public double getValor2() {
        return valor2;
    }

    public void setValor2(double valor2) {
        this.valor2 = valor2;
    }

    public double getResultado() {
        return resultado;
    }

    public void setResultado(double resultado) {
        this.resultado = resultado;
    }
    
}
