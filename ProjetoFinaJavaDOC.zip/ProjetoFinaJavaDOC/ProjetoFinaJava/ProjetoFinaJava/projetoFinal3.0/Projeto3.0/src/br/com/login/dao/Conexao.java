package br.com.login.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*Essa classe faz conexao com o banco de dados*/
public class Conexao {
    
    public Connection getConnection() throws SQLException{
        Connection conexao = (Connection) DriverManager.getConnection("jdbc:postgresql://localhost:5432/QgDoGato", "postgres", "admin");
        return conexao;
    }
    
}
