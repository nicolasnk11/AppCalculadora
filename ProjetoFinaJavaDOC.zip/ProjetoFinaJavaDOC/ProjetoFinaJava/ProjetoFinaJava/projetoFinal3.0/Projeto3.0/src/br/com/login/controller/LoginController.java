package br.com.login.controller;

import br.com.login.view.CadastroView;
import br.com.login.dao.Conexao;
import br.com.login.dao.LoginDAO;
import br.com.login.view.LoginView;
import java.sql.Connection;
import java.sql.SQLException;

/*Está Classe controla o login e o cadastro do usuario*/
public class LoginController {
    
    /*Esse metodo verifica o cadastro no banco de dados*/
    public void cadastroUsuario(CadastroView view) throws SQLException{
    
    Connection conexao = new Conexao().getConnection();
    LoginDAO cadastro = new LoginDAO();
    cadastro.cadastrarUsuario(view.getNomeCadastro().getText(), view.getEmailCadastro().getText(), view.getSenhaCadastro().getText() );
    }
    /*Esse metodo pega as informacoes passadas e verifica se existe para a efetuacao do login*/
    public void loginUsuario(LoginView view) throws SQLException{
    
    Connection conexao = new Conexao().getConnection();
    LoginDAO login = new LoginDAO();
    login.login(view.getUsuarioLogin().getText(), view.getSenhaLogin() .getText());
    }
}